const wordlist = `a`.split('\n');
module.exports = { wordlist };
